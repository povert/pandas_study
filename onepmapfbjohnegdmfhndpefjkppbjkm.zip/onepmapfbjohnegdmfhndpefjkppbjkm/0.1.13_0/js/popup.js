var e = new ext();
e.popup();